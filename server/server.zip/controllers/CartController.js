import CartModel from "../models/CartModel.js";

export async function createCart(req, res) {
    const { cartProducts, userId } = req.body;


    try {
        console.log("tryblock")

        const addProductsToCart = new CartModel(
            {
                userId: userId,
                products: cartProducts
            }
        )
        const cartSaved = await addProductsToCart.save();
        if (cartSaved) {
            return res.send({ "msg": " New Cart Added." })
        }
        return res.send("Something went wrong")
    } catch (error) {
        console.log("catchblock")
        return res.send(error)
    }
}