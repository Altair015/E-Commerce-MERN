import ProductModel from "../models/ProductModel.js";

export async function createProduct(req, res) {
    const { image, productName, age, description, price, category, quantity, userid } = req.body;
    console.log(image, productName, age, description, price, category, quantity, userid)

    if (!image || !productName || !age || !description || !price || !category || !quantity) {
        return res.status(401).json({ Entries: "Fields cannot be empty." })
    }

    const addProduct = new ProductModel(
        {
            imageUrl: image,
            title: productName,
            age: age,
            description: description,
            price: price,
            category: category,
            quantity: quantity,
            createdBy: userid
        }
    )

    try {
        // To check if the product already exist.
        const productFound = await ProductModel.findOne(
            {
                imageUrl: image,
                title: productName,
                age: age,
                description: description,
                price: price,
                category: category,
                createdBy: userid
            }
        );
        if (productFound) {
            // Updating the product Quantity if the product already exist
            const productUpdated = await productFound.updateOne({ quantity: productFound.quantity + quantity })
            if (productUpdated) {
                return res.status(208).json({ "message": "Product Updated Successfully." })
            }
        }
        else {
            // Creating a new sales record if the product does not exist.
            const productSaved = await addProduct.save();
            if (productSaved) {
                return res.status(201).json({ Created: "Product added successfully." })
            }
            else {
                return res.status(400).json({ Failure: "Something went wrong." })
            }
        }
    }
    catch (error) {
        return res.status(500).send({ message: "Internal Server Error." })
    }
}

export const getProducts = async (req, res) => {
    // for now must be replaced with the data send through the request over axiso
    const { userType, email } = req.body;
    try {
        const products = await ProductModel.find().populate("createdBy");
        console.log(products);
        if (products && userType === "seller") {
            const sellerProducts = products.filter(
                (product) => {
                    console.log(product)
                    return product.createdBy.email === email && product.createdBy.userType === userType;
                }
            )
            return res.status(201).json({ products: sellerProducts });
        }
        else if (products) {
            return res.status(201).json({ products: products });
        }
        else {
            return res.status(404).json({ Failure: "No Record Found." })
        }
    }
    catch (error) {
        console.log(error)
        return res.status(500).send({ error: error, message: "Internal Server Error." })
    }
}

export const updateProduct = async (req, res) => {
    // for now must be replaced with the data send through the request over axiso
    console.log("Updated")
    const { user, image } = req.body;
    try {
        const productUpdated = await ProductModel.findOneAndUpdate(
            {
                _id: req.params.id,
                createdBy: user
            },
            {
                imageUrl: image,
                title: productName,
                description: description,
                age: age,
            }
        );
        if (productUpdated) {
            return res.status(201).json({ "Success": "Product Updated Successfully" });
        }
        else {
            console.log("error")
            return res.status(404).json({ Failure: "No Record Found." })
        }
    }
    catch (error) {
        console.log(error)
        return res.status(500).send({ message: "Internal Server Error." })
    }
}

// controller function to delete specific product
export async function deleteProduct(req, res) {
    const { user } = req.body;

    try {
        const productDeleted = await ProductModel.findOneAndDelete({ _id: req.params.id, createdBy: user });
        if (productDeleted) {
            return res.status(201).send({ "msg": "Product Deleted Successfully." });
        }
        return res.status(400).send("Something went wrong.");
    }
    catch (error) {
        return res.status(500).send({ message: error.message })
    }
}