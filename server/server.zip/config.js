const SETTINGS = {
    MONGODB_URL: "mongodb://localhost:27017/petDb",
    JWT_SECRET: "gqKPWIeJ6amp8Xevt2yWJn7rzhjZ1FyAcCRb6mNcomI=",
    JWT_EXPIRY: 300
}

export default SETTINGS;