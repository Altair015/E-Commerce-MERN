import { Schema, model } from "mongoose";
import UserModel from "./UserModel.js"

const productSchema = new Schema(
    {
        imageUrl: {
            type: String,
            required: true,
        },
        title: {
            type: String,
            required: true
        },
        age: {
            type: Number,
            required: true
        },
        description: {
            type: String,
            required: true
        },
        price: {
            type: Number
        },
        rating: {
            type: Number,
            default: 0
        },
        category: {
            type: String
        },
        quantity: {
            type: Number
        },
        createdBy: {
            type: Schema.Types.ObjectId,
            ref: UserModel
        },
    },
    {
        timestamps: {
            createdAt: 'created_at',
            updatedAt: 'modified_on'
        }
    }
)

const ProductModel = model("ProductModel", productSchema);
export default ProductModel;