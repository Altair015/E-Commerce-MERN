import { Schema, model } from "mongoose";
import UserModel from "./UserModel.js"
import ProductModel from "./ProductModel.js";

const cartSchema = new Schema(
    {
        userId: {
            type: Schema.Types.ObjectId,
            ref: UserModel,
        },
        products: [
            {
                product_id: {
                    type: Schema.Types.ObjectId,
                    ref: ProductModel,
                },
                quantity: {
                    type: Number,
                    default: 0
                }
            }
        ],
    },
    {
        timestamps: {
            createdAt: 'created_at',
            updatedAt: 'modified_on'
        }
    }
)

const CartModel = model("CartModel", cartSchema);
export default CartModel;