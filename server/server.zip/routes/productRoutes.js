import { Router } from "express";
import { createProduct, deleteProduct, getProducts, updateProduct } from "../controllers/ProductController.js";

import authJwt from "../middlewares/authJwt.js";

const productRouter = Router();

productRouter.post("/createitem", authJwt, createProduct);
productRouter.get("/getitems", getProducts);
productRouter.put("/updateitem/:id", authJwt, updateProduct);
productRouter.delete("/deleteitem/:id", authJwt, deleteProduct);

export default productRouter;