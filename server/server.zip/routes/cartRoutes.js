import { Router } from "express";
import { createCart } from "../controllers/CartController.js";

// import authJwt from "../middlewares/authJwt.js";

const cartRouter = Router();

cartRouter.post("/createcart", createCart);
// cartRouter.get("/getcart", authJwt, getCart);
// cartRouter.put("/updatecart", authJwt, updateCart);
// cartRouter.delete("/deletecart", authJwt, deleteCart);

export default cartRouter;