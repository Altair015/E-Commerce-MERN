import { useContext } from "react";
import { contextStore } from "../context";

export function checkQuantity(productName) {
    const store = useContext(contextStore);
    const { cartItems } = store.cart
    console.log(store.cart)
    if (store.cart.length > 0) {
        const foundItem = cartItems.find(element => element.name === productName);
        if (foundItem !== undefined) {
            return foundItem.quantity
        }
    }
    return 0;
}
