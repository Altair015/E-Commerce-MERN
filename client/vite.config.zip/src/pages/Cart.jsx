import { useContext, useState } from 'react';
import { ProgressBar } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import MyCard from '../components/MyCard';
import { contextStore } from '../context';

import axios from "axios";

function Cart() {
    const store = useContext(contextStore);
    const { cartItems } = store.cart;
    console.log(store)

    return (
        <>
            <ProgressBar now={25} />
            <div className="d-flex gap-3 flex-wrap">
                {
                    cartItems.map(
                        (item, index) => {
                            return <MyCard
                                productId={item.productId}
                                quantity={item.quantity}
                            />
                        }
                    )
                }
            </div>
            <br></br>
            {cartItems.length
                ?
                <Link to="/ship">Checkout</Link>
                :
                <Link to="/">Go to Home</Link>
            }
        </>
    );
}

export default Cart;