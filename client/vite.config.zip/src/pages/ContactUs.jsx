function ContactUs() {
    return (
        <h1> ContactUs</h1>
    )
}

export default ContactUs;