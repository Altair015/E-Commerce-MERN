import { useContext } from "react";
import { Button, Container, Form, ProgressBar } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { contextStore } from "../context";

const { Group, Label, Control } = Form;

function Shipping() {
    const store = useContext(contextStore)

    const navigate = useNavigate();


    function handleSubmit(event) {
        event.preventDefault();
        navigate("/pay")
    }

    return (
        <>
            <ProgressBar now={50} />
            <Form onSubmit={handleSubmit} className='w-min-sm-75 w-min-md-50 m-auto py-4 px-4 px-sm-0'>
                <h1>Shipping Address</h1>
                <hr className="pb-2" />
                {/* Address Line 1 and Address Line 2 */}
                <Container className="d-sm-flex justify-content-between gap-4 p-0 pb-2">
                    <Group className="mb-3 w-100">
                        <Label>Address Line 1</Label>
                        <Control type="text" placeholder="House No. Building Name..." />
                    </Group>
                    <Group className="mb-3 w-100">
                        <Label>Address Line 2</Label>
                        <Control type="text" placeholder="Area/Sector..." />
                    </Group>
                </Container>

                {/* City/State/Country/Phone */}
                <Container className="d-sm-flex justify-content-between gap-4 p-0 pb-2">
                    <Group className="mb-3 w-100">
                        <Label>City / District</Label>
                        <Control type="text" placeholder="Bangalore/New York..." />
                    </Group>
                    <Group className="mb-3 w-100">
                        <Label>State / Province</Label>
                        <Control type="text" placeholder="Karnataka/Northeastern U.S..." />
                    </Group>
                </Container>

                {/* City/State/Country/Phone */}
                <Container className="d-sm-flex justify-content-between gap-4 p-0 pb-2">
                    <Group className="mb-3 w-100">
                        <Label>Country</Label>
                        <Control type="text" placeholder="India/U.S.A..." />
                    </Group>
                    <Group className="mb-3 w-100">
                        <Label>Phone</Label>
                        <Control type="number" placeholder="country-code phone-number" />
                    </Group>
                </Container>
                <Button variant="info" type="submit" className="fw-semibold rounded-1">Submit</Button>
            </Form >
        </>
    )
}

export default Shipping;