import { ProgressBar } from "react-bootstrap";

function ThankYou() {
    return (
        <>
            <ProgressBar now={100} />
            <h1>Thank You Page... Under Maintainence...</h1>
        </>
    )
}

export default ThankYou;