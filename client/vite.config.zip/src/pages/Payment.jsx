import { ProgressBar } from "react-bootstrap";

function Payment() {
    return (
        <>
            <ProgressBar now={75} />
            <h1>Payment Page. Under Maintainence....</h1>
        </>
    )
}

export default Payment;