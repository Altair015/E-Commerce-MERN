import axios from "axios";
import { contextStore } from "../context";
import { useContext } from "react";
import { Button, Container, NavDropdown, Form } from "react-bootstrap";

function Profile() {
    const store = useContext(contextStore)
    const { Group, Label, Control } = Form;
    const { firstName, lastName, email, shippingAddress } = store.storeUserData.userData;
    console.log(store.storeUserData.userData)
    return (
        <Form className='w-min-sm-75 w-min-md-50 m-auto py-4 px-4 px-sm-0'>
            <h1>User Profile</h1>
            <hr className="pb-3" />
            {/* First and Last Name */}
            <Container className="d-sm-flex justify-content-between gap-4 p-0 pb-2">
                <Form.Group className="mb-3 w-100">
                    <Form.Label>First Name</Form.Label>
                    <Form.Control type="text" defaultValue={firstName} placeholder="First Name" />
                </Form.Group>
                <Form.Group className="mb-3 w-100">
                    <Form.Label>Last Name</Form.Label>
                    <Form.Control type="text" defaultValue={lastName} placeholder="Last Name" />
                </Form.Group>
            </Container>
            {/* Email & Phone */}
            <Container className="d-sm-flex justify-content-between gap-4 p-0 pb-2">
                <Form.Group className="mb-3 w-100">
                    <Form.Label>Email</Form.Label>
                    <Form.Control type="tel" defaultValue={email} placeholder="Enter email" />
                </Form.Group>
                <Form.Group className="mb-3 w-100">
                    <Form.Label>Phone</Form.Label>
                    <Form.Control type="number" placeholder="country-code phone-number" />
                </Form.Group>
            </Container>

            <h1 className="pt-3">Shipping Address</h1>
            <hr className="pb-2" />

            {/* Address Line 1 and Address Line 2 */}
            <Container className="d-sm-flex justify-content-between gap-4 p-0 pb-2">
                <Form.Group className="mb-3 w-100">
                    <Form.Label>Address Line 1</Form.Label>
                    <Form.Control type="text" placeholder="House No. Building Name..." />
                    {/* <Form.Control type="text" defaultValue={"addressLine1"} placeholder="First Name" /> */}
                </Form.Group>
                <Form.Group className="mb-3 w-100">
                    <Form.Label>Address Line 2</Form.Label>
                    <Form.Control type="text" placeholder="Area/Sector..." />
                    {/* <Form.Control type="text" defaultValue={"addressLine2"} placeholder="First Name" /> */}
                </Form.Group>
            </Container>

            {/* City/State/Country/Phone */}
            <Container className="d-sm-flex justify-content-between gap-4 p-0 pb-2">
                <Form.Group className="mb-3 w-100">
                    <Form.Label>City / District</Form.Label>
                    <Form.Control type="text" placeholder="Bangalore/New York..." />
                </Form.Group>
                <Form.Group className="mb-3 w-100">
                    <Form.Label>State / Province</Form.Label>
                    <Form.Control type="text" placeholder="Karnataka/Northeastern U.S..." />
                </Form.Group>
            </Container>
            {/* City/State/Country/Phone */}
            <Container className="d-sm-flex justify-content-between gap-4 p-0 pb-2">
                <Form.Group className="mb-3 w-100">
                    <Form.Label>Country</Form.Label>
                    <Form.Control type="text" placeholder="India/U.S.A..." />
                </Form.Group>
                <Form.Group className="mb-3 w-100">
                    <Form.Label>Phone</Form.Label>
                    <Form.Control type="number" placeholder="country-code phone-number" />
                </Form.Group>
            </Container>
            <Button variant="info" type="submit" color="danger" className="fw-medium rounded-1">Update</Button>
        </Form >
    )
}

export default Profile;