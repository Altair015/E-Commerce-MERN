import { useContext } from 'react';
import { ProgressBar } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import MyCard from '../components/MyCard';
import { contextStore } from '../context';

function Cart() {
    const store = useContext(contextStore);
    console.log(store)
    return (
        <>
            <ProgressBar now={25} />
            <div className="d-flex gap-3 flex-wrap">
                {
                    store.cart.map(
                        (element, index) => {
                            return <MyCard key={index} image={element.image} title={element.name} quantity={element.quantity}></MyCard>
                        }
                    )
                }
            </div>
            <br></br>
            <br></br>
            {store.cart.length
                ?
                <Link to="/ship">Checkout</Link>
                :
                <Link to="/">Go to Home</Link>
            }
        </>
    );
}

export default Cart;