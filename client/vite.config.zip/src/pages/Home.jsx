import axios from "axios";
import MyCard from "../components/MyCard.jsx";
import { catFood } from "../utils/InitialData.js";
// import { checkQuantity } from "../utils/cardQuantity.js";
import { contextStore } from "../context.js";
import { useContext, useEffect } from "react";

function Home() {
    const store = useContext(contextStore);

    const { email, userType } = store.storeUserData.userData;
    const { products, setProducts } = store.storeProducts;

    function checkQuantity(productId) {
        const { cartItems } = store.cart

        if (cartItems.length > 0) {
            const foundItem = cartItems.find(element => {

                return element.productId === productId
            });
            if (foundItem !== undefined) {
                return foundItem.quantity
            }
        }
        return 0;
    }

    async function getItems() {
        try {
            const response = await axios.get("/api/getitems");
            if (response) {
                setProducts(
                    response.data.products.filter(
                        (product, index) => {
                            if (userType === "seller") {
                                return (product.createdBy.userType === userType && product.createdBy.email === email)
                            }
                            else {
                                return product
                            }
                        }
                    )
                )
            }
        }
        catch (error) {
            console.log(error)
        }
    }
    useEffect(
        () => {
            getItems()
        }, []
    )


    const catFoodComp = products.map(
        (item, index) => {

            return (
                <MyCard
                    key={item._id}
                    productId={item._id}
                    image={item.imageUrl}
                    title={item.title}
                    description={item.description}
                    quantity={checkQuantity(item._id)}
                    age={item.age}
                    price={item.price}
                    rating={item.rating}
                />
            )
        }
    )
    return (
        <div className="d-flex gap-3 flex-wrap">
            {catFoodComp}
        </div>
    )
}

export default Home;