import { catLitter } from "../utils/InitialData.js";
import MyCard from "../components/MyCard.jsx"
import { checkQuantity } from "../utils/cardQuantity.js";


function Litter() {
    const catLitterComp = catLitter.map((item, index) => <MyCard key={item.id} image={item.image} title={item.title} details={item.details} quantity={checkQuantity(item.title)} />)

    return (
        <div className="d-flex gap-3 flex-wrap">
            {catLitterComp}
        </div>
    )
}

export default Litter;