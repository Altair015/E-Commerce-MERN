const SETTINGS = {
    // BASE_URL: "http://localhost:4000",
    BASE_URL: "http://10.0.0.1:4000",
}

export default SETTINGS;