// export function addAction(action) {
//     const { type, productId, image, title, description, quantity, age, price, rating } = action;
//     return { type, productId, image, title, description, quantity, age, price, rating };
// }

// export function removeAction(action) {
//     const { type, productId } = action;
//     return { type, productId };
// }
export function addAction(action) {
    console.log(action);

    const { type, productId } = action;
    return {
        type,
        productId,
    }
}

export function removeAction(action) {
    const { type, productId } = action;
    return {
        type,
        productId
    }
}
