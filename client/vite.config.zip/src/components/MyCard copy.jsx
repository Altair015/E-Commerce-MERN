import { useContext } from 'react';
import { Button, ButtonGroup, Card, Form } from 'react-bootstrap';
import { addAction, removeAction } from '../actions/mycartAction';
import "./MyCard.css";
import { contextStore } from '../context';

function MyCard({ productId, image, title, description, quantity, age, price, rating }) {

    const store = useContext(contextStore);
    const { Img, Body, Title, Text } = Card;

    return (
        <Card className='w-25 rounded-3'>
            <Img className='card-image object-fit-cover' src={image} />
            <Body>
                <Title>{title}</Title>
                <Text>{description}</Text>
                {quantity > 0 && store.cart.filter(
                    (item) => {
                        return item.name === title
                    }
                )
                    ?
                    < ButtonGroup aria-label="Basic example" className='w-50'>
                        <Button variant="danger" onClick={() => store.cartDispatch(removeAction({ type: "-", name: title }))}>{quantity === 1 ? `${'🗑️'}` : "-"}</Button>
                        <Form.Control disabled value={quantity > 0 ? quantity : 0} className='rounded-0 text-center'></Form.Control>
                        <Button variant="success" onClick={() => store.cartDispatch(addAction({ type: "+", name: title, image: image }))}>+</Button>
                    </ButtonGroup>
                    :
                    // <Button variant="success" onClick={() => console.log(typeof (image))}>+</Button>
                    <Button variant="primary" onClick={() => store.cartDispatch(addAction({ type: "+", name: title, image: image }))} >Add to Cart</Button>

                }

            </Body>
        </Card >
    );
}

export default MyCard;